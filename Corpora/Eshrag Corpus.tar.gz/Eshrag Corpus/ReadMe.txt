Gold-Standard Arabic Twitter Corpus 2014
================================
�	Data collection 20/01/14 to 21/02/14
�	The tweets were randomised and a subset of 10,000 instances were selected to be manually annotated.
�	The annotation scheme includes 5 labels: positive, negative, neutral, uncertain and skip (redundant or advertisement)
�	The dataset is annotated with different feature-sets: morphological features, semantic features, stylistic features and social signal features.


Citation:
Refaee, E. and Rieser, V. (2014a). An Arabic twitter corpus for subjectivity and sentiment analysis. In 9th International Conference on Language Resources and Evaluation (LREC�14).
