#-------------------------
#------Tariq Alhindi------
#------ May 15, 2016------
#-------------------------
library(e1071)
library(kernlab)
library(caret)
library(randomForest)
library(rpart)
library(rpart.plot)
library(rattle)
library(RColorBrewer)    

rm(list=ls())

getwd()
setwd("C:/Users/Tariq/Dropbox (MIT)/Projects/3. ITS/Sentiment Analysis/Eshrag Corpus")
data <- read.csv("V2-GS-R&R-TwitterSentimentCorpus2014-Ar.csv")


# Creating Train and Test sets 
inTrain<- createDataPartition(y=data$Sentiment, p=0.75, list=FALSE)
Training <- data[inTrain, ] 
Testing  <- data[-inTrain, ]

#Naive Bayes
model <- naiveBayes(Sentiment ~ ., data = Training)
predict(model, Testing, type = "raw")

#SVM
svp <- ksvm( Training, Training$Sentiment, type="C-svc", kernel="vanilladot", C=100, scaled=c() )

#Using versions of "caret"
modfit <- train(Sentiment ~ ., data = Training, method="nb")






#----- Random Forest--------
modfit <- randomForest(Sentiment ~. , data=Training, method="class", na.action = na.omit)
modfit
modfit$importance
plot(modfit, log="y")
predictions <- predict(modfit, newTesting, type = "class")
confusionMatrix(predictions, newTesting$Agg.Block.Type)




