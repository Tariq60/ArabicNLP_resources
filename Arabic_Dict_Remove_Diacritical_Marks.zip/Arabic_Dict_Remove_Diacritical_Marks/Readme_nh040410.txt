Each folder contains two files, an Excel file that describes the category names and entries, and a Word file that is the LIWC dictionary that can be uploaded into the LIWC processor.

AA_LIWC: Arabic categorization scheme of function words
AE_LIWC: English translation of AA_LIWC 
EA_LIWC: Arabic translation of EE_LIWC's function words

For reference, the default dictionary that comes with LIWC may be referred to as EE_LIWC; the English categorization scheme of function and content words; original default 2007 English version of LIWC.

Loading a New Dictionary in LIWC
1. Menu --> Dictionary --> Load New Dictionary --> Browse (select appropriate dictionary)
2. Check if it is correctly uploaded, go to Categories --> (the appropriate category names should appear; alternately, check Menu --> Dictionary --> Show Current Dictionary)

LIWC Input File (to process Arabic text):
LIWC can process text files in formats such as word 2003 document (*.doc), rich text format (*.rtf) and plain text (*.txt).
LIWC supports Unicode encoding.
To process Arabic text, it is strongly recommended to use plain text format (*.txt) with UTF-8 encoding
All the Arabic diacritics must be removed from the input files.

How to Remove Diacritics from a Text (UTF-8 Encoding) File:
In Windows:

Step 1. Ensure that the file format has been changed to text UTF-8 encoding. One possible way to do this is to open the file in Microsoft word --> Save As --> select plain text format --> select UTF-8 encoding.
Step 2. Copy all UTF-8 text files into a single folder.
Step 3. Copy "remove_diac_win" folder to the same folder beside your UTF-8 files
Step 4. Go to "remove_diac_win" and double click on "remove_diac_win.exe" only once
Step 5. Go back to your files, you will find all cleaned files with the "_clean.txt" extension

In Mac:
Step 1. Ensure that the file format has been changed to text UTF-8 encoding. One possible way to do this is to open the file in Microsoft word --> Save As --> select plain text format --> select UTF-8 encoding.
Step 2. Copy all UTF-8 text files into a single folder.
Step 3. Copy "remove_diac_mac.py" to the same folder
Step 4. Open Finder --> Go --> Utilities --> Terminal.app
Step 5. In the terminal find your path (e.g. cd /your_folder/your_sub_folder/ )
Step 6. Type the following command: "python remove_diac.py"
Step 7. Output files will have the same extension and encoding, but this process will rename the new text file with "clean" at the end of the original file name.


How to Process LIWC Text Files (see also LIWC2007 user's manual, Pennebaker, Booth, & Francis, 2007):
Once the target dictionary has been uploaded, click on the icon of the running man --> select file and click select or select folder and click select all (alternately, Menu --> File --> Process Text --> select file and click select or select folder and click select all)

LIWC Output:
The output of all processed files is a plain tab-delimited data file which includes information about the input text.
The first row of output consist of LIWC category names according to the dictionary that was selected to process the text.
The rows below consist of LIWC percentages for each file. 
The first column indicates the file name. 
The subsequent columns contain percentages of total words in each file belonging to a LIWC category (indicated on the first row).

Contact info:
navidh@mail.utexas.edu (512.363.6423)
cindyk.chung@mail.utexas.edu