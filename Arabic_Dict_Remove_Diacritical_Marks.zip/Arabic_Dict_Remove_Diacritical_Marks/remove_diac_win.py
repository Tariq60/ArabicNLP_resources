# remove Arabic diacritics in python for windows
# by Navid Hayeri

import os, glob

def remove_diac(file_name):
	
	list_diac = [u"\u064B", u"\u064C", u"\u064D", u"\u064E", u"\u064F", u"\u0650", u"\u0651", u"\u0652", u"\u0653", u"\6D6", u"\u06E1", u"\u200C" ]
		
	import codecs
	
	f = codecs.open(file_name, "r", "utf-8")
	text = f.read()
	f.close()

	output =""
	for i in range(len(text)):
		flag = True
		for j in range(len(list_diac)):
			if text[i] == list_diac[j]:
				flag = False
				break
		if flag:
			output += text[i]

	output_file_name = file_name[0:-4] + "_clean.txt"
	f = codecs.open(output_file_name, "w", "utf-8")
	f.write(output)
	f.close()
# end remove_diac

# call function
path = ""
for infile in glob.glob( os.path.join(path, '*.txt') ):
         remove_diac(infile)
