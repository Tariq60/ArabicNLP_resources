Each folder contains two file, an Arabic LIWC categories (Excel file) and a liwc dictionary (doc file).

AA_LIWC: Arabic way categorization of function words
AE_LIWC: translation of AA_LIWC to English
EE_LIWC: original 2007 English version of LIWC
EA_LIWC: translation of EE_LIWC to Arabic 


Loading a New Dictionary in LIWC
1. Menu --> New Dictionary --> Browse (select LIWC_DIC.doc)
2. check if it is correctly uploaded, goto 
Categories -->


LIWC input file:
LIWC can process text files in most of popular format such as word 2003 document (*.doc), rich text format (*.rtf) and plain text (*.txt)
LIWC support Unicode encoding.
For Arabic LIWC, it's strongly suggested to use plain text format with utf-8 Encoding
All the Arabic diacritics must be removed from the input files.


Remove Diacritics from a text format (utf-8 Encoding) file:
Step1: Change the file format to text utf-8 Encoding. One possible way could be, openning the file in Microsoft word and saving as plian text format, choosing utf-8 Encoding.
Step 2. Copy all utf-8 text file and the pyuthon scrip remove_diac.py in one directory.
Step 3. Run the python script remove_diac.py in unix shell.
	> python remove_diac.py
Step 4. Output files have the same extension and Encoding, but rename to original name with "clean" at the tail.


LIWC Result Format

The output of processed file is a plain text file which include information about the input text.
The first line of output consist of liwcattribute names.(e.g. file_name, word_count, six_letter_words)
the following lines consist of liwc scores for each file. the very first column have some information about the input file. 
The rest of columns contains relative frequency (in percentile) of occurance of each category respect to number of words in each file.

